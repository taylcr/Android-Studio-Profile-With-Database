package com.example.databasewithprofiles.database.entity;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.text.SimpleDateFormat;
import java.util.Date;

@Entity (tableName = "profile_table")
public class Profile {


    @PrimaryKey (autoGenerate = false)
    @ColumnInfo (name = "ProfileID")
    public int profileID;
    @ColumnInfo (name = "surname")
    public String Surname;
    @ColumnInfo (name = "name")
    public String name;
    @ColumnInfo (name = "gpa")
    public double gpa;
    @ColumnInfo (name = "creationDate")
    public String creationDate;



    public Profile() {
        Surname = "";
        this.name = "";
        this.profileID = 0;
        this.gpa = 0.0;
        this.creationDate= null;
    }
    public Profile(String surname, String name, int uid, double gpa) {
        Surname = surname;
        this.name = name;
        this.profileID = uid;
        this.gpa = gpa;
        this.creationDate= currentDate();
    }

    public String currentDate(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(new Date());
    }

}
