package com.example.databasewithprofiles.database.doa;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;


import com.example.databasewithprofiles.database.entity.Profile;

import java.util.List;


// Data acces Object
@Dao
public interface ProfileDao {

// created, opened, closed, deleted

    @Query("SELECT * FROM profile_table")
    abstract List<Profile> getAll();


    @Query("SELECT * FROM profile_table WHERE profileID=:id")
    abstract Profile findById(int id);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract void insertAll(Profile Profiles);

    @Delete
    abstract void delete(Profile pr);


    //@Query("SELECT * FROM profile_table ORDER BY surname ASC")

    @Query("SELECT * FROM profile_table ORDER BY LOWER(surname) ASC")
    List<Profile> getAllProfilesBySurname();

    @Query("SELECT * FROM profile_table ORDER BY profileID ASC")
    List<Profile> getAllProfilesById();



    @Query("DELETE FROM profile_table")
    void deleteAll();
}
