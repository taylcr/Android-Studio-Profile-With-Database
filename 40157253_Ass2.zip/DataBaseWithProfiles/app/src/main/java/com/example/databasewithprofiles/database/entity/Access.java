package com.example.databasewithprofiles.database.entity;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.databasewithprofiles.database.AppDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

@Entity (tableName = "access_table")
public class Access {
    @ColumnInfo (name = "AccessID")
    @PrimaryKey (autoGenerate = true)
    public int accessID;
    @ColumnInfo (name = "ProfileID")
    public int profileID;
    @ColumnInfo (name = "Access_type")
    public String accessType;

    @ColumnInfo (name = "Timestamp")
    public String timeStamp;

    public String dateTime(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss");
        return dateFormat.format(new Date());
    }

// each time Profile event occurs (created, opened, closed, deleted) call this constructor and Add information on who did it

    public Access( int ID, String Type) {   // Access ID and TimeStamp get added automaticcaly - each type called...

        profileID =ID;
        accessType =Type;

        accessID =0; // auto
        this.timeStamp =dateTime();

    }

    public Access( ){
        accessID =0;
        profileID =0;
        accessType ="";
        timeStamp =null;
    }
}
