package com.example.databasewithprofiles;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.databasewithprofiles.database.AppDatabase;
import com.example.databasewithprofiles.database.entity.Access;
import com.example.databasewithprofiles.database.entity.Profile;

import java.util.List;

public class ProfileRecyclerViewAdapter extends RecyclerView.Adapter<ProfileRecyclerViewAdapter.ViewHolder> {



    private List<Profile> listOfProfile;
    public static class ViewHolder  extends RecyclerView.ViewHolder{ // activity class, like on create
        private TextView profileInfoTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            profileInfoTextView =itemView.findViewById(R.id.profileInfoTextView);  // findViewbyID
        }

        //getter
        public TextView getProfileInfoTextview(){return profileInfoTextView;}
    }

//constructor
    public ProfileRecyclerViewAdapter(List<Profile> listOfProfile) {
        this.listOfProfile = listOfProfile;
    }

    @NonNull
    @Override
    public ProfileRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // where we will inflate layout xml
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_recyclerview_item,parent,false);
       return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) { // actual text





        String surname = listOfProfile.get(position).Surname;
        String name = listOfProfile.get(position).name;
        String concatenate =String.valueOf(position+1)+". "+  surname +", "+ name;

        holder.getProfileInfoTextview().setText(concatenate);

holder.itemView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        int pos= holder.getLayoutPosition();

        Intent intent =new Intent(view.getContext(),ProfileActivity.class);
        intent.putExtra("StudentID",listOfProfile.get(pos).profileID);

        // Add accessType in Access DB
        String accessType= "Opened";
        AppDatabase db =AppDatabase.getInstance(view.getContext());
        db.accessDao().insertAll(new Access(listOfProfile.get(pos).profileID,accessType));

        view.getContext().startActivity(intent);

    }
});


    }


    @Override
    public int getItemCount() {  // length of the list ( size)
        return listOfProfile.size();
    }
}
