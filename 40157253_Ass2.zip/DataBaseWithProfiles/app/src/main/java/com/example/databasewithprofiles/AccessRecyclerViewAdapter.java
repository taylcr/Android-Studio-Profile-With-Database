package com.example.databasewithprofiles;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import com.example.databasewithprofiles.database.entity.Access;



import java.util.List;

public class AccessRecyclerViewAdapter  extends RecyclerView.Adapter<AccessRecyclerViewAdapter.ViewHolder> {



    private List<Access> listOfAccess;
    public static class ViewHolder  extends RecyclerView.ViewHolder{ // activity class, like on create
        private TextView acessInfoTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            acessInfoTextView =itemView.findViewById(R.id.profileInfoTextView);  // findViewbyID
        }

        //getter
        public TextView getProfileInfoTextview(){return acessInfoTextView;}
    }

    //constructor
    public AccessRecyclerViewAdapter(List<Access> listOfAccess) {
        this.listOfAccess = listOfAccess;
    }

    @NonNull
    @Override
    public AccessRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // where we will inflate layout xml
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_recyclerview_item,parent,false);
        return new AccessRecyclerViewAdapter.ViewHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull AccessRecyclerViewAdapter.ViewHolder holder, int position) {


        //int size =listOfProfile.size();


        String Date = listOfAccess.get(position).timeStamp;
        String Type = listOfAccess.get(position).accessType;

        String concatenate =String.valueOf(  Date +" "+ Type);

        holder.getProfileInfoTextview().setText(concatenate);


    }


    @Override
    public int getItemCount() {  // length of the list ( size)
        return listOfAccess.size();
    }
}
