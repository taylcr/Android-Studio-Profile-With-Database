package com.example.databasewithprofiles.database.doa;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;


import com.example.databasewithprofiles.database.entity.Access;


import java.util.List;


// Data acces Object
@Dao
public interface AccessDao {


    @Query("SELECT * FROM access_table")
    abstract List<Access>getAll();


    @Query("SELECT * FROM access_table WHERE profileID=:id")
    abstract Access findById(int id);


    @Query("SELECT * FROM access_table WHERE profileID=:id")
    abstract List<Access> findByIdList(int id);


    @Insert
    abstract void insertAll(Access Accesses);

    @Query("DELETE FROM access_table")
    void deleteAll();
}
