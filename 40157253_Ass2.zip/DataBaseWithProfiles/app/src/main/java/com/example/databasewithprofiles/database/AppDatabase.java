package com.example.databasewithprofiles.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


import com.example.databasewithprofiles.database.doa.AccessDao;
import com.example.databasewithprofiles.database.doa.ProfileDao;
import com.example.databasewithprofiles.database.entity.Access;
import com.example.databasewithprofiles.database.entity.Profile;

@Database(entities = {Profile.class, Access.class},version=1)
public abstract class  AppDatabase extends RoomDatabase {


    private static volatile AppDatabase instance; // makes sure only one exist at a time
    private static final String DB_NAME = "profiledatabase";

    protected AppDatabase(){} // protected so cant create DB outside this class

    private static AppDatabase create(Context context){  // create DB here instead of in constructor

        return Room.databaseBuilder(context, AppDatabase.class,DB_NAME).allowMainThreadQueries().build(); // return a instance of a build DB

    }

    public static synchronized AppDatabase getInstance(Context context) { // public visible outside the class   ----- Either create or get existing instance in main...
        if (instance == null) {
            instance = create(context); // build database
        }
        return instance;
    }

    public abstract ProfileDao profileDao(); // to acces profile DAO from the Database instance aka also outside like in the main
    public abstract AccessDao accessDao();



}
