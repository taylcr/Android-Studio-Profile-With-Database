package com.example.databasewithprofiles;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;


import com.example.databasewithprofiles.database.AppDatabase;
import com.example.databasewithprofiles.database.entity.Access;
import com.example.databasewithprofiles.database.entity.Profile;

public class InsertProfileDialogFragment extends DialogFragment {

    protected EditText surnameField;
    protected EditText nameField;
    protected EditText studentIDField;
    protected EditText GPAField;

    protected Button saveButton;
    protected Button cancelButton;


    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) { // inflate created layout

       View view = inflater.inflate(R.layout.dialogfragment_insert_profile,container); // creates the view

        surnameField = view.findViewById(R.id.surnameField);
        nameField = view.findViewById(R.id.nameField);
        studentIDField = view.findViewById(R.id.studentIDField);
        GPAField = view.findViewById(R.id.GPAField);

        saveButton = view.findViewById(R.id.yesButton);
        cancelButton = view.findViewById(R.id.noButton);


        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                AppDatabase db =AppDatabase.getInstance(getContext());

                String surname = surnameField.getText().toString();
                String name = nameField.getText().toString();
                String idString = studentIDField.getText().toString();
                String gpaString = GPAField.getText().toString();

                    // Check if any of the input values are empty
                if (surname.isEmpty() || name.isEmpty() || idString.isEmpty() || gpaString.isEmpty()) {
                    Toast.makeText(getContext(), "Please enter all values", Toast.LENGTH_LONG).show();
                    return;
                }

                            // Check if surname and name contain only letters (no special characters)
                if (!surname.matches("[a-zA-Z]+") || !name.matches("[a-zA-Z]+")) {
                    Toast.makeText(getContext(), "Invalid name or surname", Toast.LENGTH_LONG).show();
                    return;
                }

                            // Parse ID and GPA values
                int id;
                double gpa;

                try {
                    id = Integer.parseInt(idString);
                    gpa = Double.parseDouble(gpaString);
                } catch (NumberFormatException e) {
                    Toast.makeText(getContext(), "Invalid ID or GPA", Toast.LENGTH_LONG).show();
                    return;
                }

                // Check if ID is within the valid range
                if (id < 10000000 || id > 99999999) {
                    Toast.makeText(getContext(), "Invalid ID range", Toast.LENGTH_LONG).show();
                    return;
                }

                // Check if GPA is within the valid range
                if (gpa < 0 || gpa > 4.3) {
                    Toast.makeText(getContext(), "Invalid GPA range", Toast.LENGTH_LONG).show();
                    return;
                }

                    // Check if the ID already exists in the database
                Profile existingProfile = db.profileDao().findById(id);
                if (existingProfile != null) {
                    Toast.makeText(getContext(), "ID already exists", Toast.LENGTH_LONG).show();
                    return;
                }


                db.profileDao().insertAll(new Profile(surname, name, id, gpa));


                // Add accessType in Access DB
                String accessType= "Created";
                db.accessDao().insertAll(new Access(id,accessType));


                Toast.makeText(getContext(),"Profile Save successfully",Toast.LENGTH_LONG).show();



                ((MainActivity) requireActivity()).nameMode(); // after created order by surname
                dismiss();
            }
        });

        return view;



    }
}
