package com.example.databasewithprofiles;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.databasewithprofiles.database.AppDatabase;

import com.example.databasewithprofiles.database.entity.Profile;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    protected TextView modetextView;
    protected ListView listView;
    protected ImageButton dotsButtom;
    protected RecyclerView profileRecyclerView;
    protected ProfileRecyclerViewAdapter profileRecyclerViewAdapter;
    protected FloatingActionButton insertProfileButton;
    protected AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        insertProfileButton =findViewById(R.id.insertProfileButton);
        insertProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InsertProfileDialogFragment dialog = new InsertProfileDialogFragment();
                dialog.show(getSupportFragmentManager(),"InsertProfileDialog");
            }
        });

    }


    @Override
    public void onResume() {
        super.onResume();

        db = AppDatabase.getInstance(getApplicationContext());

        nameMode();

//--------------------listVIew AND DOTS------------------------------
        List<Profile> profiles = db.profileDao().getAll();


        // List view
        listView= findViewById(R.id.listViewDA);
        listView.setVisibility(View.GONE); // list initially "GONE"

        //--------------Creating List &  Change Mode----

        List<String> list = new ArrayList<>();
        list.add("By ID");
        list.add("By Name");

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {//position
                    // By ID
                    idMode();
                    listView.setVisibility(View.GONE); // hide list after choosing mode
                } else if (i == 1) {
                    //By Name
                    nameMode();
                    listView.setVisibility(View.GONE);
                }
            }
        });

        dotsButtom =findViewById(R.id.dotsButtom);

        // hide list or Show
        dotsButtom.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {   // show list or not

                int visibility = listView.getVisibility();

                if (visibility == View.VISIBLE) {
                    listView.setVisibility(View.GONE);
                }
                else{
                    listView.setVisibility(View.VISIBLE);

                }
            }
        });

    }




    public void idMode() {
        List<Profile> profiles = db.profileDao().getAllProfilesById();

        modetextView =findViewById(R.id.modetextView);
        modetextView.setText(String.valueOf(profiles.size())+" Profiles, by ID");

        LinearLayoutManager LLM =new LinearLayoutManager(this);
        profileRecyclerViewAdapter = new ProfileRecyclerViewAdapter(profiles);

        profileRecyclerView = findViewById(R.id.ProfileRecyclerView);
        profileRecyclerView.setLayoutManager(LLM);
        profileRecyclerView.setAdapter(profileRecyclerViewAdapter);


    }
    public void nameMode() {
        List<Profile> profiles = db.profileDao().getAllProfilesBySurname();

        modetextView =findViewById(R.id.modetextView);
        modetextView.setText(String.valueOf(profiles.size())+" Profiles, by Surname");


        LinearLayoutManager LLM =new LinearLayoutManager(this);
        profileRecyclerViewAdapter = new ProfileRecyclerViewAdapter(profiles);

        profileRecyclerView = findViewById(R.id.ProfileRecyclerView);
        profileRecyclerView.setLayoutManager(LLM);
        profileRecyclerView.setAdapter(profileRecyclerViewAdapter);
    }







}