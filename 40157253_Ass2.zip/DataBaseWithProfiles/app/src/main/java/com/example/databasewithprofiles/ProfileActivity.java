package com.example.databasewithprofiles;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.example.databasewithprofiles.database.AppDatabase;


import com.example.databasewithprofiles.database.entity.Access;
import com.example.databasewithprofiles.database.entity.Profile;

import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    protected AccessRecyclerViewAdapter AccessRecyclerViewAdapter;

    protected RecyclerView accessRecyclerView;


    protected ImageButton backButton;
    protected AppDatabase db;
    protected Profile currentProfile;
    protected Access currentAccess;
    protected ImageButton deleteProfileButton;
    protected TextView profileID ;

    protected TextView profileSurname;
    protected TextView profileName;
    protected TextView profileGPA;
    protected TextView profileCreation;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Intent intent =getIntent();

        deleteProfileButton= findViewById(R.id.deleteProfileButton);
        backButton = findViewById(R.id.backButton);

        profileID =findViewById(R.id.profileID);
        profileID.setText("");

        profileSurname =findViewById(R.id.profileSurname);
        profileSurname.setText("");

        profileName =findViewById(R.id.profileName);
        profileName.setText("");

        profileGPA =findViewById(R.id.profileGPA);
        profileGPA.setText("");

        profileCreation =findViewById(R.id.profileCreation);
        profileCreation.setText("");


        int StudentID =intent.getIntExtra("StudentID",-1);
        if(StudentID !=-1){
           db = AppDatabase.getInstance(this);
            currentProfile = db.profileDao().findById(StudentID);
            currentAccess = db.accessDao().findById(StudentID);


          profileID.setText("ID: "+String.valueOf(currentProfile.profileID));
            profileSurname.setText("Surname: "+currentProfile.Surname);
            profileName.setText("Name: "+currentProfile.name);
            profileGPA.setText("GPA: "+String.valueOf(currentProfile.gpa));
            profileCreation.setText("Profile Created: "+String.valueOf(currentAccess.timeStamp));



        }else{
            goToMainActivity();
        }

            deleteProfileButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    db.profileDao().delete(currentProfile);
                    Toast.makeText(getApplicationContext(),"Profile is deleted",Toast.LENGTH_LONG).show();

                    // Add accessType in Access DB
                    int profileID = currentProfile.profileID;
                    String accessType= "Deleted";
                    AppDatabase db =AppDatabase.getInstance(getApplicationContext());
                   db.accessDao().insertAll(new Access(profileID,accessType));

                    goToMainActivity();
                }
            });


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int profileID = currentProfile.profileID;

                // Add accessType in Access DB
                String accessType= "Closed";
                db.accessDao().insertAll(new Access(profileID,accessType));

                goToMainActivity();
            }
        });


        setupAccessRecyclerView();
    }



    protected void setupAccessRecyclerView(){

        int profileID = currentProfile.profileID;

        //List<Access> acc = db.accessDao().getAll();

        List<Access> accesses = db.accessDao().findByIdList(profileID) ;


        LinearLayoutManager LLM =new LinearLayoutManager(this);
        AccessRecyclerViewAdapter = new AccessRecyclerViewAdapter(accesses);

        accessRecyclerView = findViewById(R.id.accessRecyclerView);
        accessRecyclerView.setLayoutManager(LLM);
        accessRecyclerView.setAdapter(AccessRecyclerViewAdapter);

    }
void goToMainActivity(){
    Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
    startActivity(intent1);  // go back to main if not found
}


}